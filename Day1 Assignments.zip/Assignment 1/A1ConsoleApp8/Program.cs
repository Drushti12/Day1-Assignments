﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1ConsoleApp8
{
    class Program
    {
        //private static object element;

        static void Main(string[] args)
        {
            #region Arrays 1
            //string[] s = { "Riya", "Siya", "Rahul", "Sameer", "Drushti", "Ruby", "John", "Joseph", "Stephen" };
            //var str = "Drushti";

            //var result = Array.Find(s, element => element == str);
            //bool a = s.AsQueryable().Contains(str);
            //Console.WriteLine("String is in Array : "+result);
            //Console.WriteLine(a);
            //Console.ReadLine();
            #endregion

            //Search String in String Array
            Console.WriteLine("Array elements...");
            string[] s = { "Riya", "Siya", "Rahul", "Sameer", "Drushti", "Ruby", "John", "Joseph", "Stephen" };
            var str = "Drushti";
            for (int i = 0; i < s.Length; i++)
            {
                Console.Write("{0} ", s[i]);
            }
            Console.WriteLine();
            string res = Array.Find(s, ele => ele == str);
            Console.Write("Searched element is present in Array : ");
            Console.Write(" {0}", res);
            Console.ReadLine();

            //string[] s = { "Riya", "Siya", "Rahul", "Sameer", "Drushti", "Ruby", "John", "Joseph", "Stephen" };


            //Search String in String Array type 2
            Console.WriteLine("\n");
            Console.WriteLine("element to be searched");
            string a = Console.ReadLine();
            if (s.Contains(a))
            {
                Console.WriteLine("element present");
            }
            else
            {
                Console.WriteLine("element not present");
            }
            Console.ReadLine();

            //Display all Strings having 'a' character in it
            Console.WriteLine("");
            Console.WriteLine("Strings with 'a' character in it");
            for(int i=0;i<s.Length;i++)
            {
                for(int j=0;j<s[i].Length;j++)
                {
                    if (s[i].Contains("a") || s[i].Contains("A"))
                    {
                        Console.WriteLine(s[i]);
                        break;
                    }
                }               
            }
            Console.ReadLine();

            //Display String with Odd Length
            Console.WriteLine("");
            Console.WriteLine("Strings with Odd Length are ");
            for(int i=0;i<s.Length;i++)
            {
                if (s[i].Length % 2 != 0)
                {
                    Console.WriteLine(s[i]);
                }                               
            }
            Console.ReadLine();
        }
    }                            
}
