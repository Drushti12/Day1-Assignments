﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A4StackConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            //Stack<string> a = new Stack<string>();
            //Stack<string> b = new Stack<string>();
            //a.Push("Riya");
            //a.Push("Siya");
            //a.Push("Tiya");
            //a.Push("Diya");
            //a.Push("Rahul");
            //a.Push("Sameer");
            //a.Push("Joseph");

            ////Push
            //Console.WriteLine("Current Stack for Push");
            //foreach (object x in a)
            //{
            //    Console.WriteLine(x + " ");
            //}

            ////Search
            //Console.WriteLine("\n Is String present in the Stack ? " + a.Contains("Rahul"));

            ////Pop
            //Console.WriteLine("\nCurrent Stack for Pop");
            //foreach (object x in a)
            //{
            //    Console.WriteLine(x + " ");
            //}

            //Console.WriteLine("\nStack after Pop", a.Pop());
            //foreach (object x in a)
            //{
            //    Console.WriteLine(x + " ");
            //}

            ////Reverse
            //Console.WriteLine("\nCurrent Stack for Reverse");
            //foreach (object x in a)
            //{
            //    Console.WriteLine(x + " ");
            //}

            //Console.WriteLine();
            //while (a.Count != 0)
            //{
            //    b.Push(a.Pop());
            //}

            //Console.WriteLine("\nReversed Stack");
            //foreach (object x in b)
            //{
            //    Console.WriteLine(x + " ");
            //}

            //Console.ReadLine();

            //Sort
            Stack<int> s = new Stack<int>();
            s.Push(15);
            s.Push(10);
            s.Push(76);
            s.Push(2);
            s.Push(41);
            s.Push(-2);
            s.Push(22);

            Sort(s);

            //Display Current Stack after push
            Console.WriteLine("\nCurrent Stack for Sort");
            foreach (object x in s)
            {
                Console.WriteLine(x + " ");
            }
            Console.ReadLine();

            Console.WriteLine("Sorted Stack");
            while(s.Count>0)
            {
                Console.WriteLine(s.Pop());
            }
            Console.ReadLine();

            void Sort(Stack<int> stack)
            {
                if (stack.Count == 0)
                    return;

                int element = stack.Pop();

                Sort(stack);
                RI(stack, element);
            }

            Console.ReadLine();

            void RI(Stack<int> stack,int element)
            {
                if (stack.Count == 0 || element >= stack.Peek())
                    stack.Push(element);
                else
                {
                    int temp = stack.Pop();
                    RI(stack, element);
                    stack.Push(temp);
                }
            }
            Console.ReadLine();

        }
    }
}
