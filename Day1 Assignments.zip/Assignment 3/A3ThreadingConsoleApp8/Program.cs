﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace A3ThreadingConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Amount for Transaction");
            double ta = Convert.ToInt32(Console.ReadLine());

            Bank b = new Bank(ta);

            Thread t1 = new Thread(b.deposit);
            Thread t2 = new Thread(b.withdraw);

            Console.WriteLine("Deposit/Withdrawal");
            int n = Convert.ToInt32(Console.ReadLine());
            if(n==1)
            {
                Console.WriteLine("Total Amount after Deposit");
                t1.Start();
            }
            else if(n==2)
            {
                Console.WriteLine("");
                Console.WriteLine("Total Amount after WithDrawal");
                t2.Start();
            }
            else
            {
                Console.WriteLine("No Data");
            }
            Console.ReadLine();
        }
    }
}
