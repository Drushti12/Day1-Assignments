﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3ThreadingConsoleApp8
{
    class Bank
    {
        double NetBal = 10000;
        double ta;

        public void deposit()
        {
            NetBal = NetBal + ta;
            Console.WriteLine(NetBal);
        }

        public void withdraw()
        {
            NetBal = NetBal - ta;
            Console.WriteLine(NetBal);
        }

        public Bank(double ta)
        {
            this.ta = ta;
        }

        public double Netbal
        {
            get
            {
                return NetBal;
            }
            set
            {
                NetBal = value;
            }
        }
    }
}
